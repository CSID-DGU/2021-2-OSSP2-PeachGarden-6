import React from "react";

const Layout = (props) => (
    <div>
        {props.children}
    </div>
)

export default Layout
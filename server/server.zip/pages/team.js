import Layout from '../components/Layout'

export default() => (
    <Layout>
        <p>Team page</p>
    </Layout>
)
const topThreeProps = {
  "pitcher": [
    "era",
    "so",
    "wins",
    "sv",
    "hld"
  ],
  "hitter": [
    "hit_avg",
    "obp",
    "slg",
    "rbi",
    "r",
    "hr",
    "sb",
  ],
}

module.exports = {topThreeProps};
const colors = {
  main: "#df9977",
  mainFaded: "#a3c2db",
  black: "#000000",
  white: "#FFFFFF",
  gray: "#AAAAAA",
  lightgray: "#d9d9d9"
}

module.exports = { colors };